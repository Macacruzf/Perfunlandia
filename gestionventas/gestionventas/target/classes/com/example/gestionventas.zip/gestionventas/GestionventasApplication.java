package com.example.gestionventas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionventasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionventasApplication.class, args);
	}

}
